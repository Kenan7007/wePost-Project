<?php
session_start();
include ('include/header.php');
include ('include/connection.php');

if (isset($_GET['name'])){
    $name = $_GET['name'];
}

if(!isset($_SESSION['id'])) {
    echo "<div class='alert alert-danger'>" . "You need authentication to get to this page!" . "</div>";
    header('REFRESH:3;URL=login.php');
}
else{

    ?>



    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2" id="side-area">
                    <h4>Control Panel</h4>
                    <ul>
                        <li>
                            <a href="categories.php">
                                <span><i class="fas fa-tags"></i></span>
                                <span>Categories</span>
                            </a>
                        </li>

                        <li data-bs-toggle="collapse" data-bs-target="#menu">
                            <a href="#">
                                <span><i class="far fa-newspaper"></i></span>
                                <span>Articles</span>
                            </a>
                        </li>
                        <ul class="collapse" id="menu">
                            <li>
                                <a href="newPost.php">
                                    <span><i class="far fa-edit"></i></span>
                                    <span>New Article</span>
                                </a>
                            </li>

                            <li>
                                <a href="allPosts.php">
                                    <span><i class="fas fa-th-large"></i></span>
                                    <span>All Articles</span>
                                </a>
                            </li>
                        </ul>
                        <li>
                            <a href="indexADM.php" target="_blank">
                                <span><i class="fas fa-window-restore"></i></span>
                                <span>View wePost</span>
                            </a>
                        </li>

                        <li data-bs-toggle="collapse" data-bs-target="#menu1">
                            <a href="#">
                                <span><i class="fas fa-users-cog"></i></span>
                                <span>Authors & Users</span>
                            </a>
                        </li>
                        <ul class="collapse" id="menu1">
                            <li>
                                <a href="newAuthor.php">
                                    <span><i class="far fa-edit"></i></span>
                                    <span>Add New Author</span>
                                </a>
                            </li>

                            <li>
                                <a href="allAuthors.php">
                                    <span><i class="fas fa-th-large"></i></span>
                                    <span>All Authors</span>
                                </a>
                            </li>

                            <li>
                                <a href="allUsers.php">
                                    <span><i class="fas fa-users"></i></span>
                                    <span>All Users</span>
                                </a>
                            </li>
                        </ul>

                        <li>
                            <a href="logout.php">
                                <span><i class="fas fa-sign-out-alt"></i></span>
                                <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-10" id="main-aria">
                    <label><b><i>All Authors</i></b></label>
                    <!-- Display All Authors -->
                    <div class="display-authors mt-4">
                        <?php
                        if(isset($name)) {
                            $query = "DELETE FROM author WHERE name ='$name'";
                            $delete = mysqli_query($conn, $query);
                            if (isset($delete)) {
                                echo "<div class='alert alert-success'>" . "Author Removed Successfully" . "</div>";
                            } else {
                                echo "<div class='alert alert-danger'>" . "Something Went Wrong" . "</div>";
                            }
                            $query2 = "DELETE FROM posts WHERE postAuthor='$name'";
                            $delete2 = mysqli_query($conn, $query2);
                            if (isset($delete2)) {
                                echo "<div class='alert alert-success'>" . "Article(s) Deleted Successfully" . "</div>";
                            }
                        }
                        ?>

                        <table class="table table-bordered">
                            <tr>
                                <th>Author Id</th>
                                <th>Author Name</th>
                                <th>Email</th>
                                <th>Published Articles</th>
                                <th>Remove Author</th>
                            </tr>
                            <?php
                            $query = "SELECT * FROM author ORDER BY id desc ";
                            $res = mysqli_query($conn,$query);
                            while ($row = mysqli_fetch_assoc($res)){
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['published_posts']; ?></td>
                                    <td><a href="allAuthors.php?name=<?php echo $row['name']; ?>" onclick="return confirm('Are you sure you want to Remove Author (<?php echo $row['name']; ?>) With All His Articles ?')"><button class="btn-custom">Remove</button></a></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php
}
?>
<?php
include ('include/footer.php');
?>